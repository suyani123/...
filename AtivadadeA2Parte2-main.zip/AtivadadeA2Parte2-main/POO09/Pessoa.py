
class Pessoa:

    def __init__(self, nome, idade, nomePai,nomeMae):
        self.nome = nome
        self.idade = idade
        self.nomePai = nomePai
        self.nomeMae = nomeMae
