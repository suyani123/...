class livro:
    def __init__(self, codigo, nome, autor, genero, ano, qtd):
        self.codigo = codigo
        self.nome = nome
        self.autor = autor
        self.genero = genero
        self.ano = ano
        self.qtd = qtd