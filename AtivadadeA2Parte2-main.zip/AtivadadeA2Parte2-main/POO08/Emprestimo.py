class emprestimo:
    def __init__(self, codLivro, nomePessoa, dataEmprest, dataDevol):
        self.codLivro = codLivro
        self.nomePessoa = nomePessoa
        self.dataEmprest = dataEmprest
        self.dataDevol = dataDevol
