class pessoa:
    def __init__(self, nome, telefone):
        self.nome = nome
        self.telefone = telefone